/* 
 * File: init.h
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#ifndef INIT_H
#define	INIT_H

#include <xc.h>
#include <pic18f452.h>

#define _XTAL_FREQ 16000000

//------------------------------------------------------------------------------
unsigned char dat [26];//буфер для 1-го считывателя
unsigned char dat2 [26];//буфер для 2-го считывателя
unsigned char fcode = 0;//байт facility карты
unsigned char id_l = 0;//младший байт id карты
unsigned char id_h = 0;//старший байт id карты
unsigned char i = 0;//счетчик бит 1-го считывателя
unsigned char i2 = 0;//счетчик бит 2-го считывателя
unsigned char card_found = 0;//флаг "карта найдена" 
unsigned char time = 0;
unsigned char time_exit1 = 0;//время прохода 1
unsigned char time_exit2 = 0;//время прохода 2
unsigned char err_ack = 0;//ошибка ответа внешней EPPROM
unsigned char err_wcol = 0;//коллизия I2C
unsigned char addr = 0;
unsigned char h_addr = 0;
unsigned char l_addr = 0;
unsigned char data_I2C = 0;//1-й байт данных I2C
unsigned char data1_I2C = 0;//2-й байт данных I2C
unsigned char data2_I2C = 0;//3-й байт данных I2C
unsigned char data_rx = 0;
//------------------------------------------------------------------------------
void init(void);
#endif

