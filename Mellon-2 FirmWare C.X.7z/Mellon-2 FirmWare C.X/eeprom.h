/* 
 * File:   eeprom.h
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#ifndef EEPROM_H
#define	EEPROM_H

#include <xc.h>
#include <pic18f452.h>

unsigned char ee_read(unsigned char addr);

void ee_write(unsigned char addr, unsigned char data);

#endif

