/* 
 * File: utilits.h
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#ifndef UTILITS_H
#define	UTILITS_H

#include <xc.h>
#include <pic18f452.h>

void access1_on(void);
void access2_on(void);
void access1_off(void);
void access2_off(void);
void hello(void);
void reader2(void);
unsigned char pow(unsigned char a);//степень
unsigned char bin2dec(int a, int b, unsigned char array[]);
void card_search(void);

#endif