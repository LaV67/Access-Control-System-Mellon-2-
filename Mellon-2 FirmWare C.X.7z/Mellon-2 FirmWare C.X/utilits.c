/* 
 * File:   utilits.c
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#include "utilits.h"
#include "init.h"
#include "eeprom.h"

void access1_on(void){
    time_exit1 = 0;
    RD2 = 0,RD1 = 1, RD6 = 0, RD3 = 0;
}
void access2_on(void){
    time_exit2 = 0;
    RD0 = 0,RC1 = 1, RB5 = 0, RB6 = 0;
}
void access1_off(void){
    RD2 = 1, RD1 = 0, RD6 = 1, RD3 = 1;
}
void access2_off(void){
    RD0 = 1, RC1 = 0, RB5 = 1, RB6 = 1;
}
void reader2(void){   
    if (RB3 == 0){//cбор нулей D0-2
            dat2[i2] = 1;
            i2++;
            while (RB3 == 0);
    }
    if (RB2 == 0){
            dat2[i2] = 0;
            i2++;
            while (RB2 == 0);
    }
}
void hello(void){
    for(char i = 0; i < 3; i++){
        RC0 = RC1 = RD0 = RD1 = RD2 =1;
        time = 0;
        while(time <= 3);//задержка 0.1с    
        RC0 = RC1 = RD0 = RD1 = RD2 =0;
        time = 0;
        while(time <= 3);
        time = 0;
    }
    time = 0;
    while(time <= 5);
    access1_off();
    access2_off();
}
unsigned char pow(unsigned char a){
    if (a == 0) return 1;
    return 2 << (a - 1);
}
unsigned char bin2dec(int a, int b, unsigned char array[]){
    unsigned char n = 0;
    unsigned char dec = 0;
    for (int i = a; i > b; i--){
        if(array[i] == 1) dec = dec + pow(n);
        n++;
    }  
    return dec;
}
void card_search(void){
    card_found = 0;//поиск карты в EEPROM
    for(int i = 0; i < 255; i=i+3){
        if(fcode == ee_read(i) && id_h == ee_read(i+1) && id_l == ee_read(i+2)){
        card_found = 1;//карта найдена
        break;
        }
    }
}