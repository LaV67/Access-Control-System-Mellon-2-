/* 
 * File:   rs485.c
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#include "rs485.h"

void rs485_TxByte(unsigned char data){
    TRISCbits.RC5 = 0;//R/T на выход
    PORTCbits.RC5 = 1;//Команда передачи для ADM1485 
    
    CREN = 0;//Прием запрещен
    TXEN = 1;//Передача разрешена   
    TXREG = data;
    while(TRMT==0);//пока TSR полон 
    
    TXEN = 0;//Выключаем передачу   
    CREN = 1;//Прием разрешен
    PORTCbits.RC5 = 0;//Команда приема для ADM1485   
}