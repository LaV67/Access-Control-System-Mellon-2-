/* 
 * File: rs485.h
 * Author: LaV
 * Comments:
 * Revision history: 1
 */
#ifndef RS485_H
#define	RS485_H

#include <xc.h>
#include <pic18f452.h>

void rs485_TxByte(unsigned char data);//передача 1-го байта
#endif
